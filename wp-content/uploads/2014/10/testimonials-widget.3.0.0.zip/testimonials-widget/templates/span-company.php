<?php
global $tw_template_args;

$testimonial = $tw_template_args['testimonial'];
?>
<span class="company"><?php echo $testimonial['testimonial_company']; ?></span>
