<?php
global $tw_template_args;
?>
<span class="join-title"></span>
